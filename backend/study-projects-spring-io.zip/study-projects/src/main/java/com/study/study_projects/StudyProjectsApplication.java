package com.study.study_projects;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudyProjectsApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudyProjectsApplication.class, args);
	}

}
