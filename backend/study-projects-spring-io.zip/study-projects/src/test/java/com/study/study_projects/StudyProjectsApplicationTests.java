package com.study.study_projects;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudyProjectsApplicationTests {

	@Test
	void contextLoads() {
	}

}
